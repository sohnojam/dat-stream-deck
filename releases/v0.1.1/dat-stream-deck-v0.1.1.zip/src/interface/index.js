const OBSS = require('./OBSS')
const SLOBS = require('./SLOBS')

module.exports = {OBSS, SLOBS}