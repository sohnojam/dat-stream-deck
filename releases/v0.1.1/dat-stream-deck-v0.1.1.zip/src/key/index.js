const Key = require('./Key')

module.exports = {Key}