const Controller = require('./Controller')

module.exports = {Controller}